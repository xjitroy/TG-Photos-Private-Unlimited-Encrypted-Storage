# TG Photos E2EE — Codex / AI Agent Master Prompt

You are the lead engineer for TG Photos E2EE, an Android-first Telegram-backed private cloud gallery. Read the provided TG Photos E2EE Master Plan and the two UI moodboards before writing code. Implement Kotlin + Jetpack Compose Material 3 dark/light/system dynamic color, bottom tabs Photos (Cloud), Albums, Files, Private Vault, and settings in the top overflow menu. Use TDLib for approved Telegram authorization and ciphertext transport. No cloud plaintext; design versioned authenticated per-chunk encryption, encrypted manifest/thumbnail/cache, separate Vault keys, Argon2id password unlock and offline recovery. Add folder-level automatic backup via MediaStore/SAF + WorkManager, verified restore before offering backup-and-delete, smart adjacent photo prefetch, and Media3 secure video streaming with audio/subtitle tracks and resume. Build clean-room Compose UI inspired by but not copying GPL/AGPL sources. Do NOT assume unlimited Telegram capacity or claim audited zero knowledge. Start by auditing the existing repository and writing PLAN.md, ADRs, task list, module graph, risk list and tests. Implement only Phase P1 first, with mocked TDLib/crypto interfaces, and pause before irreversible operations or signing release builds. Never hardcode credentials or leak sensitive data. Provide a PR-ready diff, test logs and screenshots.

## Iteration rule
Implement one phase at a time, show tests, screenshots, changed files and security review before merge. Do not sign or release without explicit approval.

## Key sources
- Aves Gallery: https://github.com/deckerst/aves
- Ente: https://github.com/ente/ente
- Immich: https://github.com/immich-app/immich
- Fossify Gallery: https://github.com/FossifyOrg/Gallery
- Material Files: https://github.com/zhanghai/MaterialFiles
- Amaze File Manager: https://github.com/TeamAmaze/AmazeFileManager
- Photok: https://github.com/leonlatsch/Photok
- TDLib: https://github.com/tdlib/td
- AndroidX Media3: https://github.com/androidx/media
- Coil: https://github.com/coil-kt/coil
- Tink Java: https://github.com/tink-crypto/tink-java
- libsodium: https://github.com/jedisct1/libsodium
- SQLCipher Android: https://github.com/sqlcipher/sqlcipher-android
- libVLC: https://github.com/videolan/vlc-android
